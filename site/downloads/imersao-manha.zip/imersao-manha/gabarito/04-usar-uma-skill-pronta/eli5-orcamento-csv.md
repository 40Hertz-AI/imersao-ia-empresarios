# /eli5 dados/orcamento.csv

> Gerado de verdade pelo Claude Code (modelo Opus) nesta pasta, com o prompt do passo, em 26/10/2026. **Dados fictícios de exemplo.** O seu resultado vai sair diferente nas palavras; o que importa é chegar no mesmo tipo de entrega.

**Você:**

```
/eli5 dados/orcamento.csv
```

**Claude:**

**Em uma frase:** esse arquivo é a receita que a Torra Viva segue para saber quanto cobrar de um escritório pelo café do mês (dados fictícios de exemplo).

**Pensa assim:** é como calcular o lanche de uma festa. Você conta os convidados, quanto cada um come e por quantos dias, e compra os pacotes. Se compra muito, ganha desconto. Se o pedido é grande, a entrega sai de graça.
*Onde a comparação falha:* festa é uma vez só, e o orçamento se repete todo mês.

**Como funciona, passo a passo:**
1. **Quanto café:** pessoas × 2 xícaras × 10 g × 21 dias úteis. O total vira kg e é arredondado para cima, porque o café vem em pacotes de 1 kg.
2. **Quanto custa:** os kg vezes o preço do café escolhido (R$ 98, R$ 128 ou R$ 140 o kg).
3. **Desconto:** 5%, 10% ou 15% conforme o volume (a partir de 10, 20 ou 40 kg). Com contrato de 12 meses, somam-se mais 5%.
4. **Máquina e frete:** a partir de 8 kg a máquina vai emprestada sem custo. Abaixo disso, o aluguel é R$ 120. O frete custa R$ 35 e sai grátis se o café com desconto passar de R$ 600.
5. **Resultado:** soma tudo e divide pelo número de xícaras para achar o custo de cada xícara.

**Por que isso importa:** com a regra escrita, qualquer pessoa da equipe faz o mesmo orçamento, sem chute.

**Quer ir um nível acima?** No passo 6 essa receita vira uma calculadora em página web.

Marquei o passo 4 como feito. O próximo é o passo 5: `passos/05-criar-uma-skill/INSTRUCOES.md` (sugiro `/clear` antes).

