# Passo 2 · A conversa do plano B (lendo os CSV da pasta)

> Gerado de verdade pelo Claude Code (modelo Opus) nesta pasta, com o prompt do passo, em 26/10/2026. **Dados fictícios de exemplo.** O seu resultado vai sair diferente nas palavras; o que importa é chegar no mesmo tipo de entrega.

As respostas certas, para conferir, estão em `respostas-certas.md`.

**Você:**

```
Leia os arquivos .csv da pasta dados/ e me diga, em poucas linhas, o que tem em cada um.
```

**Claude:**

Os 4 arquivos de `dados/` (todos com dados fictícios de exemplo):

- **`vendas-mensais.csv`**: 107 linhas de vendas de janeiro a setembro de 2026. Cada linha mostra mês, produto, canal, quantidade, preço, faturamento, custo e lucro bruto.
- **`produtos.csv`**: catálogo com 12 produtos (cafés de 250 g, drip bag, kit presente, assinatura etc.). Traz origem, torra, notas de sabor, preço, custo, margem e desde quando cada um é vendido.
- **`clientes-b2b.csv`**: 14 empresas clientes do B2B Escritórios. Mostra segmento, cidade, nº de funcionários, café do plano, kg por mês, tipo de contrato, valor mensal, status (ativo/pausado), NPS (nota de satisfação) e observações.
- **`orcamento.csv`**: 17 regras para montar orçamento de escritório: xícaras por pessoa, preço por kg, descontos por volume e por contrato anual, máquina em comodato, frete, validade e a ordem do cálculo.


**Você:**

```
Qual produto mais faturou de janeiro a setembro? E qual vendeu mais unidades?
```

**Claude:**

Somei todos os canais, de janeiro a setembro de 2026 (dados fictícios de exemplo):

- **Maior faturamento:** Clube Torra Viva (a assinatura), com **R$ 165.189,00**. Em 2º lugar ficou o Mantiqueira Clássico 250 g, com R$ 122.220,00.
- **Mais unidades vendidas:** Mantiqueira Clássico 250 g, com **2.910 unidades**. Depois vêm o Cerrado Doce 250 g (2.100) e o Clube (2.091 assinaturas-mês).

Os rankings são diferentes porque o Clube custa R$ 79 por mês e o pacote de 250 g do Mantiqueira custa R$ 42.


**Você:**

```
Qual mês vendeu mais e qual vendeu menos? Mostre o faturamento de cada um.
```

**Claude:**

Faturamento por mês em 2026, somando todos os canais (dados fictícios de exemplo):

| Mês | Faturamento |
|---|---|
| Janeiro | R$ 59.494,00 |
| Fevereiro | R$ 56.095,00 ⬇ **menor** |
| Março | R$ 70.356,80 |
| Abril | R$ 77.616,60 |
| Maio | R$ 93.928,80 |
| Junho | R$ 90.838,80 |
| Julho | R$ 98.464,60 |
| Agosto | R$ 113.768,40 ⬆ **maior** |
| Setembro | R$ 105.015,40 |

Agosto faturou cerca de 2 vezes o que fevereiro faturou. De fevereiro a agosto o faturamento subiu quase todo mês. As únicas quedas foram em junho e setembro.


**Você:**

```
Qual canal de venda mais cresceu de janeiro para setembro? Mostre a conta.
```

**Claude:**

Em percentual, o canal que mais cresceu foi o **B2B Escritórios**. Em reais, quem mais cresceu foi a **Loja online** (dados fictícios de exemplo).

| Canal | Jan/2026 | Set/2026 | Diferença (set − jan) | Crescimento (diferença ÷ jan) |
|---|---|---|---|---|
| B2B Escritórios | R$ 4.011,00 | R$ 18.752,40 | + R$ 14.741,40 | 14.741,40 ÷ 4.011,00 = **+367,5%** |
| Clube Torra Viva (no arquivo aparece como "Assinatura") | R$ 14.299,00 | R$ 23.542,00 | + R$ 9.243,00 | 9.243,00 ÷ 14.299,00 = +64,6% |
| Loja online | R$ 29.601,00 | R$ 46.535,00 | **+ R$ 16.934,00** | 16.934,00 ÷ 29.601,00 = +57,2% |
| Cafeterias parceiras | R$ 11.583,00 | R$ 16.186,00 | + R$ 4.603,00 | 4.603,00 ÷ 11.583,00 = +39,7% |

O B2B Escritórios quase quintuplicou, mas partiu de uma base pequena. A Loja online cresceu menos em percentual e mesmo assim foi a que mais somou em reais.


**Você:**

```
Quais clientes B2B precisam de atenção (pausados, cancelados ou com nota de satisfação baixa)? Diga o motivo de cada um.
```

**Claude:**

Pela regra comum do NPS, quem dá nota de 0 a 6 é um cliente insatisfeito. Com essa regra, 2 clientes precisam de atenção, e há outros 3 para acompanhar (dados fictícios de exemplo).

**Precisam de atenção**

| Cliente | Situação | Motivo |
|---|---|---|
| B09 · Laboratório Vida Clara | **Cancelado** desde ago/2026 · NPS 4 | Cancelou depois de duas entregas atrasadas em julho. Pagava R$ 1.459,20/mês. Tem a nota mais baixa da lista. |
| B06 · Imobiliária Casa Certa | **Pausado** desde jul/2026 · NPS 6 | Pausou durante a reforma do escritório e diz que volta em novembro. Pagava R$ 743,00/mês. A nota 6 já conta como insatisfeito. |

**Para acompanhar**

| Cliente | Motivo |
|---|---|
| B05 · Coworking Ponto de Encontro | NPS 7, a nota mais baixa entre os ativos. Pediu orçamento para incluir chás, e esse pedido está em aberto. |
| B13 · Sorriso Pleno Odontologia e B14 · Hotel Serra Azul | Entraram em set/2026 e ainda não responderam à pesquisa de satisfação. |

Para novembro, a sugestão é falar com a Casa Certa para confirmar a volta do plano. O Vida Clara saiu por causa de atraso na entrega, então vale conferir se o problema se repetiu com outros clientes: `[confirmar: houve outros atrasos?]`.


**Você:**

```
Salve essas respostas em meu-trabalho/resumo-vendas.md, com "Dados fictícios de exemplo" no topo.
```

**Claude:**

Salvei as quatro respostas em `meu-trabalho/resumo-vendas.md`, com "Dados fictícios de exemplo" no topo.

Também marquei o passo 2 como feito no `progresso.md`. O passo 1 continua desmarcado. Se você já abriu a pasta no Claude Code, peça "marque o passo 1 como feito".

O próximo é o passo 3, em `passos/03-prompts-que-funcionam/INSTRUCOES.md`. É outro assunto, então comece uma conversa nova com `/clear`.

